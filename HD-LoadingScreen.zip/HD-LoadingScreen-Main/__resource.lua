resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'

author "Hercules Designs"
description "Nice Standard LoadingScreen"
version "1.0"

files {
    'index.html',
    'style.css'
}

loadscreen 'index.html'